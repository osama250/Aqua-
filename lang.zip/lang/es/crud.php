<?php

return [

    'add_new'      => 'Añadir nuevo',
    'cancel'       => 'Cancelar',
    'create'       => 'Crear',
    'edit'         => 'Editar',
    'save'         => 'Guardar',
    'detail'       => 'Detalle',
    'back'         => 'Volver',
    'search'       => 'Buscar',
    'export'       => 'Exportar',
    'print'        => 'Imprimir',
    'reset'        => 'Reiniciar',
    'reload'       => 'Recargar',
    'action'       => 'Acción',
    'id'           => 'Id',
    'created_at'   => 'Creado en',
    'updated_at'   => 'Actualizado en',
    'deleted_at'   => 'Eliminado en',
    'are_you_sure' => '¿Estás seguro?',
];
