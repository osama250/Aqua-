<?php

return [

    'add_new'      => 'اضافه',
    'cancel'       => 'لغو',
    'create'       => 'ایجاد',
    'edit'         => 'ویرایش',
    'save'         => 'ذخیره',
    'detail'       => 'جزئیات',
    'back'         => 'بازگشت',
    'search'       => 'جستجو',
    'export'       => 'استخراج',
    'print'        => 'چاپ',
    'reset'        => 'تنظیم مجدد',
    'reload'       => 'بارگیری مجدد',
    'action'       => 'عملیات',
    'id'           => 'شناسه',
    'created_at'   => 'ایجاد شده در',
    'updated_at'   => 'به روز شده در',
    'deleted_at'   => 'حذف شده در',
    'are_you_sure' => 'آیا مطمئن هستید؟',
];
