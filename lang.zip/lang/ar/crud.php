<?php

return [

    'add_new'      => 'إضافة جديد',
    'cancel'       => 'إلغاء',
    'create'       => 'إنشاء',
    'edit'         => 'تعديل',
    'save'         => 'حفظ',
    'delete'       => 'جذف',
    'detail'       => 'التفاصيل',
    'back'         => 'العودة',
    'search'       => 'البحث',
    'export'       => 'تصدير',
    'print'        => 'طباعة',
    'reset'        => 'استعادة',
    'reload'       => 'إعادة تحميل',
    'action'       => 'عملية',
    'id'           => 'Id',
    'created_at'   => 'تاريخ الإنشاء',
    'updated_at'   => 'تاريخ آخر تعديل',
    'deleted_at'   => 'تاريخ الحذف',
    'are_you_sure' => 'هل أنت متأكد؟',
];
