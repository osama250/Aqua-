<?php

namespace App\Http\Requests;

use App\Models\Cabin;
use Illuminate\Foundation\Http\FormRequest;

class CreateCabinRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }


    public function rules()
    {
        return Cabin::rules();
    }
}
