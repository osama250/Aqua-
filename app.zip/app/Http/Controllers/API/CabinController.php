<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Cabin;

class CabinController extends Controller
{
    public function cabins() {
        // return response()->json( ['cabins' => Cabin::with('facilites', 'facilites.category')->get() ] , 200 );
        // return response()->json( ['cabins' => Cabin::with( 'categories' , 'categories.facilites')->get() ] , 200 );
        // return response()->json( ['cabins' => Cabin::with( 'categories' ,'categories.facilites' )->get() ] , 200 );
        // return response()->json( ['cabins' => Cabin::with( 'categories.facilites' )->get() ] , 200 );
        // return response()->json( ['cabins' => Cabin::with( 'categories.c'  )->find($cabinid) ] , 200 );

        // $categories = $cabin->categories;

        // $facilities = $categories->flatMap(function ($category) use ($cabin) {
        //     return $category->facilities->where('cabin_id', $cabin->id);
        // });

            // return response()->json( ['cabins' => Cabin::with( 'categories.facilites'  )->get() ] , 200 );
            return response()->json( ['cabins' => Cabin::with( 'facilites'  )->get() ] , 200 );


            // $cabin = Cabin::find(6);
            // $cabin = Cabin::with(['categories.facilites' , function($q) {
            //         $q->where('cabin_id' , $cabin->id );
            // } ])->get();
            // return $cabin;

    }
}
