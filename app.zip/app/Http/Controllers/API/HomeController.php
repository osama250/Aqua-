<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Gallery;
use App\Models\Partner;
use App\Models\Page;
use App\Models\Unique;

class HomeController extends Controller
{
    public function homePage() {
        $partners       = Partner::all();
        $facilityHome   = Page::all();
        $unique         = Unique::all();
        return response()->json( [
            'partners'      => $partners,
            'facilityHome'  => $facilityHome,
            'unique'        => $unique,
        ]);
    }
}
