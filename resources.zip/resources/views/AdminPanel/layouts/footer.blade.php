<div class="app-container container-fluid d-flex flex-column flex-md-row flex-center flex-md-stack py-3">
    <!--begin::Copyright-->
    <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-semibold me-1">{{Date('Y')}}&copy;</span>
        <a  class="text-gray-800 text-hover-primary">TechVillage</a>
    </div>
    <!--end::Copyright-->
    <!--begin::Menu-->

    <!--end::Menu-->
</div>
