@extends('AdminPanel.app')
@section('content')
@endsection
